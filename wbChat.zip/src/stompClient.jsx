import { Client } from "@stomp/stompjs";

// STOMP 클라이언트 생성
const stompClient = new Client({
    brokerURL: "ws://localhost:8080/ws/chat",  // STOMP WebSocket 서버 URL
    connectHeaders: {},
    debug: (str) => console.log(str),  // 디버깅 로그
    reconnectDelay: 5000,  // 재연결 딜레이
    onConnect: () => {
        console.log("STOMP 연결됨!");

        // 메시지 구독
        stompClient.subscribe("/sub/chat/room", (message) => {  // room/number
            console.log("받은 메시지:", JSON.parse(message.body));
        });
    },
    onStompError: (frame) => {
        console.error("STOMP 오류:", frame);
    }
});

// STOMP 연결 활성화
export const connectStomp = () => {
    if (!stompClient.connected) {
        console.log("STOMP 연결 시도...");
        stompClient.activate();  // stompClient 활성화
    } else {
        console.log("STOMP 클라이언트가 이미 활성화되어 있습니다.");
    }
};

// STOMP 메시지 전송
export const sendMessage = (message) => {
    if (stompClient.connected) {
        stompClient.publish({
            destination: "/pub/chat/message",
            body: JSON.stringify({ content: message }),  // 메시지 내용
        });
    } else {
        console.log("STOMP 클라이언트가 연결되지 않았습니다.");
    }
};

export default stompClient;
