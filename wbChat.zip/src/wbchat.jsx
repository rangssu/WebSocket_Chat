import React, { useState, useEffect } from "react";
import stompClient, { sendMessage } from './stompClient';  // stompClient와 sendMessage 임포트

const WbChat = () => {
    const [messages, setMessages] = useState([]);
    const [message, setMessage] = useState("");

    useEffect(() => {
        // STOMP 클라이언트가 이미 활성화되어 있지 않으면 활성화
        if (!stompClient.connected) {
            console.log("STOMP 연결 시도...");
            stompClient.activate();  // stompClient 활성화
        }

        stompClient.onConnect = () => {
            console.log("STOMP 연결됨!");

            // 메시지 구독
            stompClient.subscribe("/sub/chat/room", (message) => {
                console.log("받은 메시지:", JSON.parse(message.body));
                setMessages((prev) => [...prev, JSON.parse(message.body)]);
            });
        };

        stompClient.onStompError = (frame) => {
            console.error("STOMP 오류:", frame);
        };

        return () => {
            // 컴포넌트가 언마운트되면 연결 종료
            if (stompClient.connected) {
                stompClient.deactivate();  // STOMP 연결 종료
            }
        };
    }, []);  // 컴포넌트가 처음 마운트될 때만 실행

    const sendChatMessage = () => {
        if (message) {
            sendMessage(message);  // 메시지 전송
            setMessage("");  // 메시지 입력란 비우기
        }
    };

    return (
        <div>
            <h1>웹소켓 연결 테스트</h1>
            <div>
                {messages.map((msg, index) => (
                    <p key={index}>{msg.content}</p>  // 받은 메시지 표시
                ))}
            </div>
            <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="메시지를 입력하세요"
            />
            <button onClick={sendChatMessage}>전송</button>
        </div>
    );
};

export default WbChat;
